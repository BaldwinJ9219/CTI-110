a = 2
b = 3
print(a)
print(b)
print(a+b)
print(a*b)

c = 4
d = 5
print(c)
print(d)
print(c+d)
print(c*d)

e = 6
f = 3
print(e)
print(f)
print(e+f)
print(e*f)